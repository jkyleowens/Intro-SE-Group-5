Member 1: 
Tahsin Tasnia Khan; 
Github user name: tasnia87; 
Role: Backend management


Member 2:
Kyler Shields;
Github user name: DJKYL64;
Role: Front End Designer

Member 3:
Kyle Owens;
Github username: jkyleowens;
Role: Project organization

Member 4:
Olivia Tyler;
Github username: olt28
Role: Front End Designer

Member 5:
Jocelyn Solito;
Github username: jsolit
Role: 



Language and Techniques we want to use:
HTML, CSS, and node.js with the Express.js framework for the backend. DB Browser with sqlite will be used for creating, accessing, and modifying the database.


Product Descriptions:
The product is a webapp based on Javascript, CSS, and HTML that contains a catalog of digital and physical books, which can be browsed and purchased by customers using the site. Admins will be able to add or remove books, update quantities, and manage inventory. Users will be able to browse and search books, edit personal information like address or payment, add or remove a specified quantity of books to the cart, and check out to place an order.

Objectives:
Admins will be able to add or remove books, update quantities, and manage inventory. Users will be able to browse and search books, edit personal information like address or payment, add or remove a specified quantity of books to the cart, and check out to place an order.

Features: 
The major functions that the e-store must perform are:
Home Page
Registering
Logging In
Book Catalog
Shopping Cart
Checkout



